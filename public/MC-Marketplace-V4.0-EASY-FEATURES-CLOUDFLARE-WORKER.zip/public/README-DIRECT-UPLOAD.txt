M.C Marketplace V3.11.1 — Cloudflare static frontend patch

PATCHED WITHOUT REMOVING EXISTING SITE FEATURES
- Homepage catalogue: bounded Firestore read (max 50 products) instead of scanning the full collection.
- Homepage Firestore timeout: diagnostic guard increased from 12s to 20s.
- Catalogue retry button: fixed for module scope; no more inline onclick dependency.
- Product page similar-products query: bounded to 12 documents.
- Vendor shop page: reads only that vendor's products using vendeurId/vendeurUid queries instead of the entire products collection.
- Cart panel markup typo fixed.
- Cloudflare security headers and redirects restored for the Workers/static-assets deployment path.

IMPORTANT
- Firestore Rules were NOT weakened or replaced in this frontend package.
- Current active rule for products (`allow read: if true;`) remains compatible with the public catalogue.
- Payments remain deferred as planned.

DIRECT UPLOAD
Use the contents of this ZIP for the static asset upload method you are already using.
For the GitHub/Workers Builds method, use the separate Workers package prepared alongside this archive.
