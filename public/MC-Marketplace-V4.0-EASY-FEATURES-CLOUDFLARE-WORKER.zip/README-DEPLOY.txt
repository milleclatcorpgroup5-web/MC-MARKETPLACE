M.C Marketplace V3.11.1 — FIXED CLOUDFLARE WORKER BUILD

Architecture:
- Cloudflare Worker static assets
- wrangler.jsonc -> name: bold-boat-f397
- Firebase project -> mc-marketplaceht

Changes:
- Homepage catalogue query bounded to 50 products.
- Homepage timeout guard 12s -> 20s for diagnosis.
- Retry button fixed for module scope.
- Similar-product query bounded to 12 documents.
- Vendor shop page no longer scans all products; it queries vendeurId/vendeurUid.
- Cart panel markup typo corrected.
- _headers and _redirects included for the Workers/static-assets path.

Firestore rules were not changed in this package.
Payments remain deferred.
