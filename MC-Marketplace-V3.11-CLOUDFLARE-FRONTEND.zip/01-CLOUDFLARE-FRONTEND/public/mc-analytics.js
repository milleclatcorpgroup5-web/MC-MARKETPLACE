/* M.C Marketplace — Analytics client V1
 * Privacy-first: only authenticated users send minimal activity events.
 */
const MC_ANALYTICS_FIREBASE_CONFIG = {
  apiKey: "AIzaSyB_1RmQ3t-8Zzpg-mirSCv59KrioDsmjT8",
  authDomain: "mc-marketplaceht.firebaseapp.com",
  projectId: "mc-marketplaceht",
  storageBucket: "mc-marketplaceht.firebasestorage.app",
  messagingSenderId: "788708293876",
  appId: "1:788708293876:web:09922c1e17ed6f51a2b2a1"
};
(async()=>{
  try {
    const [{initializeApp},{getAuth,onAuthStateChanged},{getFirestore,collection,addDoc}] = await Promise.all([
      import("https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js"),
      import("https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js"),
      import("https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js")
    ]);
    const app=initializeApp(MC_ANALYTICS_FIREBASE_CONFIG,"mc-analytics");
    const auth=getAuth(app), db=getFirestore(app);
    const path=location.pathname.split('/').pop()||'index.html';
    const productId=new URLSearchParams(location.search).get('id');
    async function sendEvent(user,eventName,extra={}){
      try{await addDoc(collection(db,'analytics_events'),{uid:user.uid,eventName,eventPath:path,productId:productId||null,referrer:document.referrer?new URL(document.referrer).hostname:null,clientTs:new Date().toISOString(),source:'web',appVersion:'V3.8.5',...extra});}catch(e){console.debug('[MC analytics]',e?.code||e);}
    }
    onAuthStateChanged(auth, async user=>{
      if(!user) return;
      const sessionKey=`mc_analytics_sent:${path}:${productId||''}`;
      if(!sessionStorage.getItem(sessionKey)){
        sessionStorage.setItem(sessionKey,'1');
        await sendEvent(user,path==='produit.html'&&productId?'product_view':'page_view');
      }
      let timer;
      document.querySelectorAll('input[type="search"],input[placeholder*="recherch" i]').forEach(input=>input.addEventListener('change',()=>{
        clearTimeout(timer); timer=setTimeout(()=>{const q=String(input.value||'').trim().slice(0,100);if(q)sendEvent(user,'search',{searchTerm:q});},500);
      }));
    });
  }catch(e){console.debug('[MC analytics init]',e);}
})();
