/* M.C Marketplace V3.11 — payment placeholder state.
 * Intentionally disabled until real provider integration is implemented.
 */
export const MC_PAYMENT_CONFIG = Object.freeze({
  enabled: false,
  orderPaymentEnabled: false,
  walletDepositEnabled: false,
  walletWithdrawalEnabled: false,
  vendorSubscriptionPaymentEnabled: false,
  providers: Object.freeze({ moncash:false, natcash:false, card:false }),
  message: 'Peman sou entènèt poko aktive. Pa mete kle/provider secrets nan frontend.'
});
