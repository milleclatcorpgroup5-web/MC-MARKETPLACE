/* M.C Marketplace — GPS utility layer */
(function(){
  'use strict';
  const EARTH=6371000;
  function isSupported(){ return typeof navigator !== 'undefined' && !!navigator.geolocation; }
  function getCurrentPosition(options){
    return new Promise((resolve,reject)=>{
      if(!isSupported()) return reject(Object.assign(new Error('GEOLOCATION_UNSUPPORTED'),{code:'UNSUPPORTED'}));
      navigator.geolocation.getCurrentPosition(resolve,reject,Object.assign({enableHighAccuracy:true,timeout:12000,maximumAge:15000},options||{}));
    });
  }
  function watchPosition(onPosition,onError,options){
    if(!isSupported()){ onError && onError(Object.assign(new Error('GEOLOCATION_UNSUPPORTED'),{code:'UNSUPPORTED'})); return null; }
    return navigator.geolocation.watchPosition(onPosition,onError,Object.assign({enableHighAccuracy:true,maximumAge:10000},options||{}));
  }
  function clearWatch(id){ if(isSupported() && id != null) navigator.geolocation.clearWatch(id); }
  function distanceMeters(lat1,lng1,lat2,lng2){
    const a1=Number(lat1),b1=Number(lng1),a2=Number(lat2),b2=Number(lng2);
    if(![a1,b1,a2,b2].every(Number.isFinite)) return Infinity;
    const p1=a1*Math.PI/180,p2=a2*Math.PI/180;
    const dp=(a2-a1)*Math.PI/180,dl=(b2-b1)*Math.PI/180;
    const h=Math.sin(dp/2)**2+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)**2;
    return EARTH*2*Math.atan2(Math.sqrt(h),Math.sqrt(1-h));
  }
  function normalize(position){
    const c=position?.coords || position || {};
    return {
      lat:Number(c.latitude ?? c.lat), lng:Number(c.longitude ?? c.lng),
      accuracy:Number.isFinite(Number(c.accuracy))?Number(c.accuracy):null,
      altitude:Number.isFinite(Number(c.altitude))?Number(c.altitude):null,
      heading:Number.isFinite(Number(c.heading))?Number(c.heading):null,
      speed:Number.isFinite(Number(c.speed))?Number(c.speed):null,
      capturedAt:new Date().toISOString(),
      isMoving:Number.isFinite(Number(c.speed)) ? Number(c.speed)>0.8 : false
    };
  }
  async function locateDetailed(options){
    const pos=await getCurrentPosition(options);
    const gps=normalize(pos);
    let address={};
    try{
      const controller=new AbortController();
      const timer=setTimeout(()=>controller.abort(),5000);
      const url=`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${encodeURIComponent(gps.lat)}&lon=${encodeURIComponent(gps.lng)}&zoom=18&addressdetails=1&accept-language=fr`;
      const res=await fetch(url,{headers:{Accept:'application/json'},signal:controller.signal});
      clearTimeout(timer);
      if(res.ok){
        const data=await res.json(); const a=data.address||{};
        address={
          fullAddress:data.display_name||'', country:a.country||'', department:a.state||a.region||'',
          city:a.city||a.town||a.village||a.municipality||'', neighborhood:a.suburb||a.neighbourhood||a.quarter||'',
          street:a.road||'', houseNumber:a.house_number||''
        };
      }
    }catch(_){ /* GPS remains usable without reverse geocoding. */ }
    return {...gps,address};
  }
  function formatAddress(gps){
    const a=gps?.address||{};
    return a.fullAddress || [a.street && (a.houseNumber?`${a.houseNumber} ${a.street}`:a.street),a.neighborhood,a.city,a.department].filter(Boolean).join(' · ') || `${Number(gps?.lat).toFixed(6)}, ${Number(gps?.lng).toFixed(6)}`;
  }
  function accuracyLabel(value){
    const n=Number(value);
    if(!Number.isFinite(n)) return 'Presizyon GPS pa disponib.';
    if(n<=15) return `GPS trè presi (±${Math.round(n)} m)`;
    if(n<=50) return `GPS presi (±${Math.round(n)} m)`;
    if(n<=150) return `GPS ase bon (±${Math.round(n)} m)`;
    return `GPS fèb (±${Math.round(n)} m)`;
  }
  function errorMessage(err){
    const code=err && err.code;
    if(code===1) return 'Pèmisyon Location la refize.';
    if(code===2) return 'GPS la pa disponib oswa pa jwenn yon pozisyon.';
    if(code===3) return 'GPS la pran twòp tan pou reponn.';
    if(err?.message==='GEOLOCATION_UNSUPPORTED') return 'Navigatè a pa sipòte GPS.';
    return 'Pa kapab jwenn pozisyon an.';
  }
  window.MCGPS={isSupported,getCurrentPosition,watchPosition,clearWatch,distanceMeters,normalize,locateDetailed,formatAddress,accuracyLabel,errorMessage};
})();
