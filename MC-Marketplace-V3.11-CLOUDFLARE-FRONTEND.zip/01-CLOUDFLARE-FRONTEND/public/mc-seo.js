/* M.C Marketplace V3.11 — lightweight runtime SEO helpers.
 * Static meta descriptions are still placed in HTML; this only normalizes canonical/OG URL.
 */
(() => {
  try {
    const url = new URL(location.href);
    const canonical = url.origin + url.pathname + url.search;
    let link = document.querySelector('link[rel="canonical"]');
    if (!link) { link = document.createElement('link'); link.rel='canonical'; document.head.appendChild(link); }
    link.href = canonical;
    let og = document.querySelector('meta[property="og:url"]');
    if (!og) { og=document.createElement('meta'); og.setAttribute('property','og:url'); document.head.appendChild(og); }
    og.content = canonical;
  } catch (_) {}
})();
