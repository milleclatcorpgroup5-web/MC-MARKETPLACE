/* M.C Marketplace Service Worker — PWA shell + FCM background notifications */
const CACHE='mc-marketplace-shell-v3-11-0';
const SHELL=['./index.html','./manifest.json','./404.html','./robots.txt','./sitemap.xml','./mc-payment-config.js','./mc-seo.js','./icons/icon-192.png','./icons/icon-512.png'];
self.addEventListener('install',event=>{
  event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(SHELL)).then(()=>self.skipWaiting()));
});
self.addEventListener('activate',event=>{
  event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));
});
self.addEventListener('fetch',event=>{
  const req=event.request;
  if(req.method!=='GET') return;
  const url=new URL(req.url);
  if(url.origin!==self.location.origin) return;
  event.respondWith(fetch(req).then(res=>{
    const copy=res.clone(); caches.open(CACHE).then(c=>c.put(req,copy)).catch(()=>{}); return res;
  }).catch(()=>caches.match(req).then(r=>r||caches.match('./index.html'))));
});
self.addEventListener('notificationclick',event=>{
  event.notification.close();
  const target=new URL(event.notification.data?.url||'./index.html',self.location.href).href;
  event.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(list=>{
    for(const client of list){ if('focus' in client){ client.navigate(target); return client.focus(); } }
    return self.clients.openWindow(target);
  }));
});
try{
  importScripts('https://www.gstatic.com/firebasejs/10.12.0/firebase-app-compat.js','https://www.gstatic.com/firebasejs/10.12.0/firebase-messaging-compat.js');
  firebase.initializeApp({
    apiKey:'AIzaSyB_1RmQ3t-8Zzpg-mirSCv59KrioDsmjT8',
    authDomain:'mc-marketplaceht.firebaseapp.com',
    projectId:'mc-marketplaceht',
    storageBucket:'mc-marketplaceht.firebasestorage.app',
    messagingSenderId:'788708293876',
    appId:'1:788708293876:web:09922c1e17ed6f51a2b2a1'
  });
  const messaging=firebase.messaging();
  messaging.onBackgroundMessage(payload=>{
    const n=payload.notification||{};
    const title=n.title||payload.data?.title||'M.C Marketplace';
    const options={
      body:n.body||payload.data?.body||'Nouvo aktivite sou M.C Marketplace.',
      icon:n.icon||'/icons/icon-192.png',
      badge:n.badge||'/icons/icon-192.png',
      data:{url:payload.data?.url||'./index.html'}
    };
    return self.registration.showNotification(title,options);
  });
}catch(_){ /* FCM is optional until browser/console messaging is configured. */ }
