/* M.C Marketplace — FCM device notification bridge V3.3
 * Stores only the current user's own token under /tokens/{uid}/devices/{tokenId}.
 */
(function(){
  'use strict';
  async function digestId(value){
    try{
      const bytes=new TextEncoder().encode(value);
      const hash=await crypto.subtle.digest('SHA-256',bytes);
      return [...new Uint8Array(hash)].map(b=>b.toString(16).padStart(2,'0')).join('').slice(0,40);
    }catch(_){ return btoa(unescape(encodeURIComponent(value))).replace(/[^a-zA-Z0-9_-]/g,'').slice(0,40) || 'device'; }
  }
  async function enable(opts){
    opts=opts||{};
    if(!opts.uid) throw new Error('AUTH_REQUIRED');
    if(!window.isSecureContext) throw new Error('SECURE_CONTEXT_REQUIRED');
    if(!('Notification' in window)) throw new Error('NOTIFICATION_UNSUPPORTED');
    if(!('serviceWorker' in navigator)) throw new Error('SERVICE_WORKER_UNSUPPORTED');
    const permission=await Notification.requestPermission();
    if(permission!=='granted') throw new Error('NOTIFICATION_PERMISSION_DENIED');

    const registration=await navigator.serviceWorker.register('sw.js');
    const firebaseApp=await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js');
    const messagingLib=await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-messaging.js');
    let app;
    try { app=firebaseApp.getApp('__mc_messaging__'); }
    catch(_) { app=firebaseApp.initializeApp(opts.firebaseConfig||{},'__mc_messaging__'); }
    const messaging=messagingLib.getMessaging(app);
    const tokenOptions={serviceWorkerRegistration:registration};
    if(opts.vapidKey) tokenOptions.vapidKey=opts.vapidKey;
    const token=await messagingLib.getToken(messaging,tokenOptions);
    if(!token) throw new Error('FCM_TOKEN_EMPTY');
    const id=await digestId(token);
    const now=new Date().toISOString();
    await opts.setDoc(opts.doc(opts.db,'tokens',opts.uid,'devices',id),{
      uid:opts.uid, token, active:true, platform:'web',
      userAgent:navigator.userAgent.slice(0,500), updatedAt:now,
      createdAt:now
    },{merge:true});
    return token;
  }
  window.MCNotifications={enable};
})();
