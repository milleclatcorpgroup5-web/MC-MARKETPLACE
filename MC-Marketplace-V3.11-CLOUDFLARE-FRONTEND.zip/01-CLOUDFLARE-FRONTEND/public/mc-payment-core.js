/* M.C Marketplace — Payment request foundation
 * Browser may create pending requests only. It never credits/debits a wallet.
 */
function positiveAmount(value){
  const n=Number(value);
  if(!Number.isFinite(n) || n<=0 || n>1000000) throw new Error('INVALID_AMOUNT');
  return Math.round(n);
}
function cleanNote(value){ return String(value ?? '').trim().slice(0,300); }
function makeReference(prefix){
  const now=Date.now().toString(36).toUpperCase();
  let rnd='';
  try { rnd=crypto.randomUUID().replace(/-/g,'').slice(0,12).toUpperCase(); }
  catch(_){ rnd=Math.random().toString(36).slice(2,14).toUpperCase(); }
  return `${prefix}-${now}-${rnd}`;
}
export async function createDepositRequest({db,addDoc,collection,uid,amount,method,note}){
  if(!uid) throw new Error('AUTH_REQUIRED');
  const value=positiveAmount(amount);
  if(!['moncash','natcash','card'].includes(method)) throw new Error('INVALID_METHOD');
  const now=new Date().toISOString();
  return addDoc(collection(db,'wallet_deposit_requests'),{
    uid, amount:value, currency:'HTG', method,
    status:'pending', reference:makeReference('MCDEP'),
    note:cleanNote(note), createdAt:now, updatedAt:now
  });
}
export async function createWithdrawalRequest({db,addDoc,collection,getDoc,doc,uid,amount,method,note}){
  if(!uid) throw new Error('AUTH_REQUIRED');
  const value=positiveAmount(amount);
  if(!['moncash','natcash'].includes(method)) throw new Error('INVALID_METHOD');
  const wallet=await getDoc(doc(db,'wallets',uid));
  if(!wallet.exists()) throw new Error('WALLET_NOT_FOUND');
  const available=Number(wallet.data()?.availableBalance||0);
  if(!Number.isFinite(available) || available<value) throw new Error('INSUFFICIENT_BALANCE');
  const now=new Date().toISOString();
  return addDoc(collection(db,'wallet_withdrawal_requests'),{
    uid, amount:value, currency:'HTG', method,
    status:'pending', reference:makeReference('MCWDR'),
    note:cleanNote(note), createdAt:now, updatedAt:now
  });
}
